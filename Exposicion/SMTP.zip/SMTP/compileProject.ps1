mvn clean package
